import { createContext , useState } from "react"
import React from "react";

export const formContext = React.createContext();

export function FormProvider({children}) {
    const [formData, setFormData] = useState({ nom : "", email : "", adresse: "", commentaire :""});
    const [formDataCopy, setFormDataCopy] = useState({nom : "", email : "", adresse: "", commentaire :""});
    const [submitted, setSubmitted] = useState(false);

    function handleChange(event) {
      const { name, value } = event.target;
      setFormData({ ...formData, [name]: value });
      setFormDataCopy({...formData, [name]: value});
    }

    function handleSubmit(event) {
      if (cart.length > 0 && formData.nom && formData.adresse && formData.email) {
        setSubmitted(true);
        postDataToFirebase(cart, formData);
      } else {
        if(formData.nom && formData.adresse && formData.email)
        {
          alert("Le panier est vide, ajoutez des articles avant de soumettre le formulaire")
        } else{
        alert("Veuillez remplir entiÃ¨rement le formulaire de contact");
        }
      }
      setFormData({ name: '', email: '', address: '', comments: '' });
    }
  
    return (
      <formContext.Provider value={{ formData, formDataCopy, handleChange, handleSubmit, submitted }}>
        {children}
      </formContext.Provider>
    );
  }
  export default FormProvider ; 